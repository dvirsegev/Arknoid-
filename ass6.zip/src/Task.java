/**
 * @param <T> Generic type.
 */
public interface Task<T> {
    /**
     * @return null.
     */
    T run();
}
